package com.fis.bankapplication.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;



//{
//	"customerId" : 101,
//	"customerName" : "Pranay",
//	"customerDob" : 2000-03-02,
//	"customerPno" : 9999990000,
//	"customerMail" : " Pranay@mail.com",
//	"customerPerAdd": "Hyderabad",
//	"customerCurrAdd" : "Pune",
//	"password" : "101@Pranay";
//	"occupation" : "IT Employee"
//}
@RestController //to create restful WebServices and for mapping request data to the defined request handler method
@RequestMapping("/customer") //to map HTTP requests to handler methods
public class CustomerController {
	@Autowired //to injects dependency objects automatically
	CustomerService cusserv;
	
	//mapping HTTP POST requests onto specific handler methods
	@PostMapping("/addCustomer")// http://localhost:8080/customer/addCustomer
	public  String addCusdet (@RequestBody @Validated  Customer cus) {
		return cusserv.addCusdet(cus);
	}
	
	//mapping HTTP PUT requests onto specific handler methods.
	@PutMapping("/updateCustomer")// http://localhost:8080/customer/updateCustomer
	public String updateCusdet(@RequestBody @Validated  Customer cus) {
		return cusserv.updateCusdet(cus);
	}
	
	//mapping HTTP DELETE requests onto specific handler methods
	@DeleteMapping("/deleteCustomer/{cid}")// http://localhost:8080/customer/deleteCustomer/222	
	public String delCusdet(@PathVariable("cid") int cusId) {
		return cusserv.delCusdet(cusId);
	}
	
    //mapping HTTP GET requests onto specific handler methods
	@GetMapping("/getCustomer/{cid}") // http://localhost:8080/customer/getcustomer/111
	public Customer getCustomer(@PathVariable("cid") int cusID) {
		return cusserv.getCustomer(cusID);
	}
	
	//mapping HTTP GET requests onto specific handler methods
	@GetMapping("/getAllCustomers") // http://localhost:8080/customer/getAllCustomers
	public List<Customer> getAllCustomer() {
		return cusserv.getAllCustomer();
	}
}
