package com.fis.bankapplication.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;


@Entity // to map this class to table 
@Table(name = "account_data") // Here we are initializing the table 
public class Account {
	@Size(min=100,max=10000000,message ="Enter valid customer id ") // it is used to restrict the filed length to 10000000
	private int customerId;
	@Id // To make account number as primary key entity
	@Column(name = "aid") // given the column name as aid
	@NotEmpty (message= "Account number can't be empty") // To restrict the account number from giving empty/null values
	private long accNum;
	private String accType;
	private Date accOpenDate;
	@Size(min= 0, max=1000000000 , message ="The amount must be in given limits ") //it is used to restrict the filed length to 10000000
	private double accBalance;
	
	
	// Getters and Setters
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public Date getAccOpenDate() {
		return accOpenDate;
	}
	public void setAccOpenDate(Date accOpenDate) {
		this.accOpenDate = accOpenDate;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}
	//ToSting Method
	
	@Override
	public String toString() {
		return String.format("Account [customerId=%s, accNum=%s, accType=%s, accOpenDate=%s, accBalance=%s]",
				customerId, accNum, accType, accOpenDate, accBalance);
	}
	
	//  Constructor
	public Account(int customerId, long accNum, String accType, Date accOpenDate, double accBalance) {
		super();
		this.customerId = customerId;
		this.accNum = accNum;
		this.accType = accType;
		this.accOpenDate = accOpenDate;
		this.accBalance = accBalance;
	}
	
	// Default Constructor
	public Account() {
		
	}

}
