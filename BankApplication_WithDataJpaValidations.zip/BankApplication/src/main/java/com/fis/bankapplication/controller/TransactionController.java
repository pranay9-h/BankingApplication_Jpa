package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.TransactionService;

@RestController //to create restful WebServices and for mapping request data to the defined request handler method
@RequestMapping("/transaction") //to map HTTP requests to handler methods
public class TransactionController {
	@Autowired //to injects dependency objects automatically
	TransactionService transer;
	
	//mapping HTTP POST requests onto specific handler methods.
	@PostMapping("/addTransaction")// http://localhost:8080/transaction/addTransaction
	public String addTransaction(@RequestBody Transaction transaction) {
		return transer.addTransaction(transaction);
	}
	
	//mapping HTTP GET requests onto specific handler methods
	@GetMapping("/allTransactions")// http://localhost:8080/transaction/allTransactions
	public List<Transaction> getAllTransactions(){
		return transer.getAllTransactions();
	}
	
	//mapping HTTP GET requests onto specific handler methods
	@GetMapping("/transactionsByAccNum/{accNum}")// http://localhost:8080/transaction/transactionsByAccNum/
	public List<Transaction> getAllTransactionsByAccno(@PathVariable("accNum") long accNum){
		return transer.getAllTransactionsByAccno(accNum);
	}
	

}
