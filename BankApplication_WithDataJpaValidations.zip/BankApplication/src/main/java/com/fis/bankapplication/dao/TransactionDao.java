 package com.fis.bankapplication.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fis.bankapplication.model.Transaction;

public interface TransactionDao extends JpaRepository<Transaction,Long> {
	
//	   public abstract String addTransaction(Transaction transaction);
//	   
//	   public abstract List<Transaction> getAllTransactions();
//	   
	@Query("select t from Transaction t where t.fromAcc =?1 OR t.toAcc = ?1") // Sql Query for getting all transactions by account number 
	   public List<Transaction> getAllTransactionsByAccno(long accNum);

}
