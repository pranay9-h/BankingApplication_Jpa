package com.fis.bankapplication.dao;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.bankapplication.model.Customer;

public interface CustomerDao extends JpaRepository<Customer, Integer>  {
//
//    public abstract String addCusdet(Customer cus);
//    
//    public abstract String updateCusdet(Customer cus);
//    
	
//	public String addCusdet(Customer cus);
//	
//	public String UpdateCusdet(Customer cus);
//	
//    public  String delCusdet(int cusId);
//    
//    public  Customer getCustomer(int cusID);
//    
//    public  List<Customer> getAllCustomer();

}
