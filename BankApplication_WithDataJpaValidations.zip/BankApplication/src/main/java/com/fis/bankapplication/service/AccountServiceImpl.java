package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.exceptionhandling.AccountNotFound;
import com.fis.bankapplication.exceptionhandling.LessBalanceException;
import com.fis.bankapplication.model.Account;

@Service//annotate java classes that perform some service.
@Transactional //commit the actions we perform to the database from service
public class AccountServiceImpl implements AccountService {
	
	@Autowired  //It injects dependency objects automatically
	AccountDao accdao;

	@Override // child class overrides base class
	public String addAccdet(Account acc) {
		// TODO Auto-generated method stub
		accdao.save(acc);
		return "Account Details are saved Successfully";
	}

	@Override // child class overrides base class
	public String updateAccdet(Account acc) {
		// TODO Auto-generated method stub
		 accdao.save(acc);
		 return "Account Details are Updated Successfully";
	}

	@Override // child class overrides base class
	public String delAccdet(long accId) {
		// TODO Auto-generated method stub
		 accdao.deleteById(accId);
		 return "Account Details Are Deleted Successfully";
	}

	@Override// child class overrides base class
	public Account getAccount(long accId) {
		// TODO Auto-generated method stub
		Optional<Account> optional = accdao.findById(accId);
		return optional.get();
	}

	@Override// child class overrides base class
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return accdao.findAll();
	}

	@Override// child class overrides base class
	public String deposit(long accNum, double accBal)throws AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional =  accdao.findById(accNum);
		if(optional.isPresent()) {
			accdao.deposit(accNum, accBal);
			return "Amount Deposited Successfully";
		}else {
			throw new AccountNotFound("Sorry there is no Account with give credientials ");
		}
		 
	}

	@Override// child class overrides base class
	public String withdraw(long accNum, double accBal) throws LessBalanceException,AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional =  accdao.findById(accNum);
		if(optional.isPresent()) {
			if(optional.get().getAccBalance()>accBal ) {
				accdao.withdraw(accNum, accBal);
				return "Amount Deposited Successfully";
			}else {
				throw new LessBalanceException("Your Account Balnce is Low");
			}

		}else {
			throw new AccountNotFound("Sorry there is no Account with give credientials ");
		}
	}

	@Override// child class overrides base class
	public String fundTransfer(long accNum1, long accnum2, double accBal, String type2) throws LessBalanceException,AccountNotFound {
		// TODO Auto-generated method stub
		Optional<Account> optional1 = accdao.findById(accNum1);
		Optional<Account> optional2 =accdao.findById(accnum2);
		if (optional1.isEmpty()) {
			throw new AccountNotFound("Sorry there is no Account with give credientials ");
		}if(optional2.isEmpty()) {
			throw new AccountNotFound("Sorry there is no Account with give credientials ");
		}if (optional1.get().getAccBalance() < accBal) {
			throw new LessBalanceException("Your Account Balnce is Low");
		}else {
			withdraw(accNum1,accBal);
			deposit(accnum2,accBal);
			return "Amount Transferd Successfully";
		}
		 
	}
	
	

}
