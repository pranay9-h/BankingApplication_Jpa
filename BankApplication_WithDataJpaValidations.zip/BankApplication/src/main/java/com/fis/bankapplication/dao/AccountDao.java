package com.fis.bankapplication.dao;

import com.fis.bankapplication.model.Account;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


public interface AccountDao extends JpaRepository<Account , Long>  {

	
//    public  String addAccdet(Account acc);
//    
//    public  String updateAccdet(Account acc);
//    
//    public  String delAccdet(long accId);
//    
//    public  Account getAccount(long accId);
//    
//    public  List<Account> getAllAccounts();
    
    @Query("update Account a set a.accBalance = accBalance + ?2 where a.accNum= ?1") // Sql Query for depositing the amount in account
    @Modifying
    public  void deposit (long accNum , double accBal); // Exception Added
    
    @Query("update Account a set a.accBalance = accBalance - ?2 where a.accNum= ?1 ") // Sql query for withdrawing the amount from account 
    @Modifying
    public  void withdraw(long accNum, double accBal); // Exception Added
    
    //public  String fundTransfer(long accNum1, long accnum2, double accBal,String type2) throws LessBalanceException, AccountNotFound;  // Exception Added
}

